# Gokite SDK

SDK collection for Gokite L1.

## Directory Structure

```
sdk/
├── aa/                     # Account Abstraction SDK
│   ├── gokite-aa-sdk.ts    # Main AA SDK
│   ├── example.ts          # Usage examples
│   ├── example-token-paymaster.ts
│   └── buy-content.ts
├── staking/                # Delegator Staking SDK
│   ├── staking-example.ts  # Staking SDK
│   └── test-staking.ts     # Test script
├── config.ts               # Network configuration
├── types.ts                # Type definitions
├── utils.ts                # Utilities
└── index.ts                # Entry point
```

---

# Account Abstraction SDK

Account Abstraction (EIP-4337) SDK for Gokite.

## Installation

```bash
npm install gokite-aa-sdk
```

## Quick Start

```typescript
import { GokiteAASDK } from 'gokite-aa-sdk';
import { ethers } from 'ethers';

// Initialize SDK
const sdk = new GokiteAASDK(
  'kite_testnet',
  'https://rpc-testnet.gokite.ai',
  'http://localhost:14337/rpc/' // bundler URL
);

// Owner address (from your social login SDK)
const owner = '0x...';

// Get account address (can get aa wallet address even if the wallet is not deployed)
const accountAddress = sdk.getAccountAddress(owner);

// Sign function - integrate with your social login SDK
const signFunction = async (userOpHash: string): Promise<string> => {
  // Use your preferred signing method (Particle, Privy, etc.)
  return await signer.sign(ethers.getBytes(userOpHash));
};

// Send transaction
const userOpHash = await sdk.sendUserOperation(
  owner,
  {
    target: '0x...',
    value: ethers.parseEther('0.1'),
    callData: '0x'
  },
  signFunction
);

// Wait for confirmation
const status = await sdk.pollUserOperationStatus(userOpHash);
console.log('Transaction status:', status);
```

## API Reference

### GokiteAASDK

#### Constructor

```typescript
new GokiteAASDK(network: string, rpcUrl: string, bundlerUrl?: string)
```

#### Methods

- `getAccountAddress(owner: string, salt?: bigint): string` - Calculate account address
- `sendUserOperation(owner: string, request: UserOperationRequest | BatchUserOperationRequest, signFn: SignFunction, salt?: bigint, paymasterAddress?: string): Promise<string>` - Send transaction
- `pollUserOperationStatus(userOpHash: string, options: PollingOptions = {}): Promise<UserOperationStatus>` - Wait for confirmation
- `isAccountDeloyed(accountAddress: string): Promise<boolean>` - Check if account is deployed

### Types

```typescript
interface UserOperationRequest {
  target: string;
  value?: bigint;
  callData: string;
}

interface BatchUserOperationRequest {
  targets: string[];
  values?: bigint[];
  callDatas: string[];
}

interface SignFunction {
  (userOpHash: string): Promise<string>;
}
```

## Examples

### Single Transaction

```typescript
const request = {
  target: '0x...',
  value: ethers.parseEther('0.1'),
  callData: '0x'
};

const userOpHash = await sdk.sendUserOperation(owner, request, signFunction);
```

### Batch Transactions

```typescript
const batchRequest = {
  targets: ['0x...', '0x...'],
  values: [ethers.parseEther('0.1'), 0n],
  callDatas: ['0x', '0x...']
};

const userOpHash = await sdk.sendUserOperation(owner, batchRequest, signFunction);
```

### Integration with Particle

#### docs: 

https://developers.particle.network/api-reference/auth/desktop-sdks/web#personal-signatures

```typescript
// After configuring AuthCoreContextProvider and logging in
const { signMessage } = useEthereum();

const signFunction = async (userOpHash: string): Promise<string> => {
  return await signMessage(userOpHash)
};
```

## Supported Networks

- **kite_testnet**: Kite Testnet (Chain ID: 2368)

## Requirements

- Node.js >= 16
- ethers >= 6.0.0

## License

MIT
